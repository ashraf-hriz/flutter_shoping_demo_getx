import 'package:flutter/material.dart';
import 'package:flutter_custom_clippers/flutter_custom_clippers.dart';
import 'package:flutter_svg/flutter_svg.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Flutter custom clipper example"),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(14.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Stack(
                children: [
                  SvgPicture.asset(
                    'assets/icons/center_cart_icon.svg',
                    color: Colors.black,
                  ),
                  Positioned(left: 12, top: 7, child: Text('mmmmmm')),
                ],
              ),
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  border: Border.all(
                    width: 2,
                    color: Colors.black38,
                    style: BorderStyle.solid,
                  ),
                  color: Colors.white,
                  shape: BoxShape.circle,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class CustomClipPath extends CustomClipper<Path> {
  var bRadius = 1.0;

  @override
  Path getClip(Size size) {
    /*final path = Path()
      ..lineTo(0, 0)
      ..lineTo(0, size.height)
      ..lineTo(size.width, size.height)
      //..cubicTo(size.width, bRadius, size.width, size.height * 0.6, bRadius, size.height * 0.6)
      ..lineTo(size.width, size.height * 0.6 - bRadius)
      //..cubicTo(size.width , size.height * 0.6 - bRadius, size.width , size.height * 0.6, size.width * 0.75, bRadius)
      ..lineTo(size.width * 0.75, 0)
      ..close();*/
    final path = Path();
    path.lineTo(size.width * 0.37, 0.93);
    path.cubicTo(size.width * 0.37, 0.93, size.width * 0.02, 0.93,
        size.width * 0.02, 0.93);
    path.cubicTo(size.width * 0.02, 0.93, size.width * 0.02, 0.88,
        size.width * 0.02, 0.88);
    path.cubicTo(size.width * 0.02, 0.88, size.width * 0.37, 0.88,
        size.width * 0.37, 0.88);
    path.cubicTo(size.width * 0.37, 0.88, size.width * 0.37, 0.93,
        size.width * 0.37, 0.93);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) {
    return true;
  }
}

class MyPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    Paint paint = Paint();
    Path path = Path();

    // Path number 1

    paint.color = Color(0xffffffff).withOpacity(0);
    path = Path();
    path.lineTo(size.width * 0.29, -0.93);
    path.cubicTo(size.width * 0.29, -0.93, size.width * 0.07, -0.93,
        size.width * 0.07, -0.93);
    path.cubicTo(size.width * 0.05, -0.93, size.width * 0.03, -0.92,
        size.width * 0.03, -0.91);
    path.cubicTo(size.width * 0.03, -0.89, size.width * 0.05, -0.88,
        size.width * 0.07, -0.88);
    path.cubicTo(
        size.width * 0.07, -0.88, size.width / 3, -0.88, size.width / 3, -0.88);
    path.cubicTo(size.width * 0.35, -0.88, size.width * 0.36, -0.89,
        size.width * 0.36, -0.9);
    path.cubicTo(size.width * 0.36, -0.9, size.width * 0.35, -0.9,
        size.width * 0.35, -0.91);
    path.cubicTo(size.width * 0.35, -0.91, size.width * 0.32, -0.92,
        size.width * 0.32, -0.92);
    path.cubicTo(size.width * 0.31, -0.92, size.width * 0.3, -0.93,
        size.width * 0.29, -0.93);
    path.cubicTo(size.width * 0.29, -0.93, size.width * 0.29, -0.93,
        size.width * 0.29, -0.93);
    canvas.drawPath(path, paint);

    // Path number 2

    paint.color = Color(0xffffffff).withOpacity(0);
    path = Path();
    path.lineTo(0, 0);
    path.cubicTo(0, 0, size.width, 0, size.width, 0);
    path.cubicTo(size.width, 0, size.width, -1, size.width, -1);
    path.cubicTo(size.width, -1, 0, -1, 0, -1);
    path.cubicTo(0, -1, 0, 0, 0, 0);
    canvas.drawPath(path, paint);

    // Path number 3

    paint.color = Color(0xffee6a61);
    path = Path();
    path.lineTo(size.width * 0.37, -0.93);
    path.cubicTo(size.width * 0.37, -0.93, size.width * 0.02, -0.93,
        size.width * 0.02, -0.93);
    path.cubicTo(size.width * 0.02, -0.93, size.width * 0.02, -0.88,
        size.width * 0.02, -0.88);
    path.cubicTo(size.width * 0.02, -0.88, size.width * 0.37, -0.88,
        size.width * 0.37, -0.88);
    path.cubicTo(size.width * 0.37, -0.88, size.width * 0.37, -0.93,
        size.width * 0.37, -0.93);
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return true;
  }
}
